# From-scratch implementations tied directly to the Banach fixed-point
# theorem (proved in reports/report.qmd): fixed-point iteration itself,
# an empirical check of the contraction condition the theorem requires,
# the theorem's own a priori error bound, and Newton's method as a
# second, faster-converging application of the same underlying idea.

#' Iterate x_{n+1} = g(x_n) from a starting point until successive
#' iterates are within `tol` of each other (or max_iter is reached).
#' This IS the constructive content of the Banach fixed-point theorem's
#' proof -- the theorem doesn't just assert a fixed point exists, it
#' proves this exact iteration converges to it, which is why running it
#' is a direct test of the theorem rather than an unrelated numerical
#' trick.
#'
#' @param g The map to iterate, a function of one numeric argument.
#' @param x0 Starting point.
#' @param tol Stop when |x_{n+1} - x_n| < tol.
#' @param max_iter Maximum number of iterations.
#' @return A list: root (final iterate), history (all iterates,
#'   including x0), iterations (count), converged (logical).
fixed_point_iterate <- function(g, x0, tol = 1e-10, max_iter = 200) {
  history <- numeric(max_iter + 1)
  history[1] <- x0
  x <- x0

  for (i in seq_len(max_iter)) {
    x_new <- g(x)
    history[i + 1] <- x_new
    if (abs(x_new - x) < tol) {
      return(list(root = x_new, history = history[seq_len(i + 1)], iterations = i, converged = TRUE))
    }
    x <- x_new
  }
  list(root = x, history = history, iterations = max_iter, converged = FALSE)
}

#' Empirically estimate a map's Lipschitz constant on an interval:
#' L = sup_{x != y} |g(x) - g(y)| / |x - y|. The Banach fixed-point
#' theorem requires g to be a CONTRACTION -- Lipschitz with constant
#' L < 1 -- so this function exists to check that precondition
#' numerically BEFORE trusting that fixed_point_iterate() is even
#' guaranteed to converge, rather than assuming it.
#'
#' @param g The map to check.
#' @param interval c(lower, upper) bound of the domain to sample from.
#' @param n_samples Number of random (x, y) pairs to sample.
#' @return The largest observed |g(x)-g(y)|/|x-y| ratio -- an estimate
#'   of L, not a proof (a true supremum would need calculus, e.g.
#'   bounding |g'(x)|, to establish rigorously).
estimate_lipschitz_constant <- function(g, interval, n_samples = 5000) {
  x <- runif(n_samples, interval[1], interval[2])
  y <- runif(n_samples, interval[1], interval[2])
  # Avoid division by (near) zero when x and y land very close together
  keep <- abs(x - y) > 1e-8
  x <- x[keep]; y <- y[keep]

  ratios <- abs(g(x) - g(y)) / abs(x - y)
  max(ratios)
}

#' The Banach fixed-point theorem's own A PRIORI error bound: before
#' running ANY iterations beyond the first, the theorem guarantees
#'   |x_n - x*| <= (L^n / (1 - L)) * |x_1 - x_0|.
#' "A priori" means this bound can be computed from L, x0, and x1
#' alone -- it does not require knowing x* (the fixed point) or running
#' the iteration out to n steps first, which is what makes it a
#' genuinely predictive theorem, not just a description of what
#' happened after the fact.
#'
#' @param x0, x1 The first two iterates.
#' @param L The (estimated) Lipschitz/contraction constant.
#' @param n The iteration count to bound the error at.
#' @return The theoretical upper bound on |x_n - x*|.
banach_a_priori_bound <- function(x0, x1, L, n) {
  (L^n / (1 - L)) * abs(x1 - x0)
}

#' Newton's method, expressed explicitly as fixed-point iteration with
#' g(x) = x - f(x)/f'(x) -- so it can be run through the exact same
#' fixed_point_iterate() function above. Newton's method is NOT
#' globally a contraction (g'(x*) = 0 at a simple root makes it a
#' contraction only LOCALLY, near x*, which is also why Newton's method
#' can fail to converge from a poor starting guess even though it
#' converges extremely fast from a good one -- see the report for the
#' empirical convergence-order comparison this enables).
#'
#' @param f The function whose root is sought.
#' @param f_prime f's derivative.
#' @param x0 Starting guess.
#' @param tol, max_iter As in fixed_point_iterate().
#' @return Same return shape as fixed_point_iterate().
newton_as_fixed_point <- function(f, f_prime, x0, tol = 1e-10, max_iter = 200) {
  g <- function(x) x - f(x) / f_prime(x)
  fixed_point_iterate(g, x0, tol = tol, max_iter = max_iter)
}

#' Estimate the empirical ORDER of convergence from a sequence of
#' iterates and the true fixed point: order p satisfies, approximately,
#' |e_{n+1}| ~ C |e_n|^p, so p can be recovered as the slope of
#' log|e_{n+1}| regressed on log|e_n|. Linear convergence (contraction
#' mappings generally) has p ~ 1; Newton's method near a simple root
#' has p ~ 2 (quadratic) -- this function makes that textbook claim
#' checkable directly against simulated iteration histories.
#'
#' @param history A numeric vector of iterates (from
#'   fixed_point_iterate()$history).
#' @param true_root The known true fixed point/root to measure error against.
#' @return The estimated order p (a single number).
estimate_convergence_order <- function(history, true_root) {
  errors <- abs(history - true_root)
  errors <- errors[errors > 1e-15]   # drop iterates that already hit machine precision -- log(0) is undefined and later "errors" there are just floating-point noise, not information about the convergence rate
  n <- length(errors)
  if (n < 3) return(NA_real_)

  log_e_n   <- log(errors[1:(n - 1)])
  log_e_np1 <- log(errors[2:n])
  fit <- lm(log_e_np1 ~ log_e_n)
  unname(coef(fit)[2])
}
