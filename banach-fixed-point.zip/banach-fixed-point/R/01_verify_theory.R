library(dplyr)
source("R/contraction_functions.R")

cat("=== 1. A classic contraction: g(x) = cos(x) on [0, 1] ===\n")
g_cos <- function(x) cos(x)

# This is a textbook contraction: |g'(x)| = |sin(x)| <= sin(1) < 1 on
# [0, 1], so the interval maps into itself and the Banach fixed-point
# theorem guarantees a unique fixed point there, reached from ANY
# starting point in [0, 1].
L_estimated <- estimate_lipschitz_constant(g_cos, interval = c(0, 1))
cat("Estimated Lipschitz constant L on [0,1]:", round(L_estimated, 4),
    " (theoretical: sin(1) =", round(sin(1), 4), ")\n")
cat("Contraction? (L < 1):", L_estimated < 1, "\n")

cos_result <- fixed_point_iterate(g_cos, x0 = 0.5)
cat("\nConverged to:", format(cos_result$root, digits = 12), "in", cos_result$iterations, "iterations\n")
cat("True fixed point (uniroot cross-check): ")
true_cos_root <- uniroot(function(x) cos(x) - x, c(0, 1), tol = 1e-15)$root
cat(format(true_cos_root, digits = 12), "\n")

cat("\n=== 2. The a priori error bound, checked at several n ===\n")
x0 <- 0.5
x1 <- g_cos(x0)
bound_check <- lapply(c(1, 2, 5, 10, 20, cos_result$iterations), function(n) {
  if (n > length(cos_result$history) - 1) n <- length(cos_result$history) - 1
  actual_error <- abs(cos_result$history[n + 1] - true_cos_root)
  theoretical_bound <- banach_a_priori_bound(x0, x1, L_estimated, n)
  data.frame(n = n, actual_error = actual_error, theoretical_bound = theoretical_bound,
             bound_holds = actual_error <= theoretical_bound)
}) |> bind_rows() |> distinct(n, .keep_all = TRUE)
print(bound_check)

cat("\n=== 3. Newton's method as a (locally) contracting fixed-point map ===\n")
# Root of f(x) = x^2 - 2, i.e. sqrt(2), via Newton's method starting
# from x0 = 1.
f  <- function(x) x^2 - 2
fp <- function(x) 2 * x

newton_result <- newton_as_fixed_point(f, fp, x0 = 1)
cat("Newton converged to:", format(newton_result$root, digits = 15), "in", newton_result$iterations, "iterations\n")
cat("True root (sqrt(2)):", format(sqrt(2), digits = 15), "\n")

cat("\n=== 4. Convergence order: linear (cosine fixed point) vs. quadratic (Newton) ===\n")
order_cos    <- estimate_convergence_order(cos_result$history, true_cos_root)
order_newton <- estimate_convergence_order(newton_result$history, sqrt(2))
cat("Estimated convergence order, cos(x) fixed-point iteration:", round(order_cos, 3), "(theory: ~1, linear)\n")
cat("Estimated convergence order, Newton's method:             ", round(order_newton, 3), "(theory: ~2, quadratic)\n")

saveRDS(list(
  L_estimated = L_estimated,
  cos_result = cos_result, true_cos_root = true_cos_root,
  bound_check = bound_check,
  newton_result = newton_result,
  order_cos = order_cos, order_newton = order_newton
), "data/clean/verification_results.rds")
