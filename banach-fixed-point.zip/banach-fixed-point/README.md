# The Banach Fixed-Point Theorem

**Question:** *(fill in)* Under what conditions does repeatedly applying a map to a starting guess provably converge, how fast, and why does Newton's method converge so much faster than a generic fixed-point iteration?

**Key findings:** *(fill in after rendering; did the empirical Lipschitz constant match sin(1), did the a priori error bound hold at every checked step, and how did the estimated convergence orders for the two methods compare to the theoretical 1 vs. 2?)*

**Tools:** R (base only for the core implementation), Quarto report with LaTeX theorem statement and full proof

## Why this project exists

Second in a series of projects pairing a pure-mathematics result (stated and proved properly, with a full proof here rather than a sketch) with a from-scratch implementation and numerical verification — built for an MSc Pure Mathematics portfolio, while staying connected to the numerical-methods side of the data-analyst track (fixed-point iteration and Newton's method underlie a large share of applied numerical computing).

## Reproduce

1. No non-base packages required for `R/01_verify_theory.R`; `install.packages(c("tidyverse"))` for rendering the report
2. Run `R/01_verify_theory.R` — verifies a classic contraction ($\cos(x)$ on $[0,1]$), checks the theorem's a priori error bound, runs Newton's method as a second application, and estimates both methods' empirical convergence order
3. Render `reports/report.qmd` for the full theorem statement, complete proof, and verification plots

## The theorem

> Let $(X,d)$ be a nonempty **complete** metric space and $g:X\to X$ a **contraction** ($d(g(x),g(y)) \le L\,d(x,y)$ for some $L<1$). Then $g$ has a unique fixed point $x^*$, the iteration $x_{n+1}=g(x_n)$ converges to it from any starting point, and $d(x_n,x^*) \le \frac{L^n}{1-L}d(x_1,x_0)$.

Unusually among existence theorems, the proof is fully constructive: the Cauchy-sequence argument that proves a fixed point exists *is* the fixed-point-iteration algorithm, and the error bound falls directly out of the same argument.

## Method in brief

1. Implement fixed-point iteration directly from the proof's construction.
2. Empirically estimate a map's Lipschitz constant by sampling, and check it against a calculus-derived theoretical value for a known example.
3. Verify the theorem's own a priori error bound holds at every checked iteration — not as a close call, but as a guarantee the theorem makes unconditionally.
4. Express Newton's method as a fixed-point iteration too, and compare its empirical convergence order (quadratic, since $g'(x^*)=0$ at a simple root) against a generic contraction's (linear).

## Project structure

```
R/contraction_functions.R   fixed_point_iterate, estimate_lipschitz_constant,
                             banach_a_priori_bound, newton_as_fixed_point,
                             estimate_convergence_order
R/01_verify_theory.R        runs the cosine example, the a priori bound check,
                             Newton's method, and the convergence-order comparison
reports/report.qmd          full theorem statement, proof, and verification
```

## Limitations

- The Lipschitz constant is estimated by random sampling, not proven analytically (except for the one worked calculus example in the report).
- Newton's quadratic convergence is a *local* result; only a single well-behaved example with a good starting guess is tested here.
- *(add your own)*
